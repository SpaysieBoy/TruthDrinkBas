﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TruthDrinkBas.Model;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TruthDrinkBas.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PicturePage : ContentPage
    {
        public PicturePage()
        {
            InitializeComponent();
        }

        private void ZoekCocktailNameButton_Clicked(object sender, EventArgs e)
        {
            var cocktails = CocktailLogic.GetCocktailsByName(CocktailNameEntry.Text);

        }
    }
}